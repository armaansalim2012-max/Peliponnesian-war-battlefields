const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");
const PORT = process.env.PORT || 3000;
const MAX_PER_TEAM = 30, WORLD = 90;
const players = new Map(), sockets = new Map();
let nextId = 1;

const server = http.createServer((req,res)=>{
  const pathname = decodeURIComponent((req.url||"/").split("?")[0]);
  const file = pathname === "/" ? "index.html" : pathname.replace(/^\/+/,"");
  const full = path.resolve(__dirname,file);
  if (!full.startsWith(path.resolve(__dirname)+path.sep)) {res.writeHead(403);return res.end("Forbidden");}
  fs.readFile(full,(err,data)=>{
    if(err){res.writeHead(404);return res.end("Not found");}
    const ext=path.extname(full);
    res.writeHead(200,{"Content-Type":({".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json"}[ext]||"application/octet-stream"),"Cache-Control":"no-cache"});
    res.end(data);
  });
});
const wss = new WebSocket.Server({server});
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const send=(ws,obj)=>{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));};
function publicState(){
 return {type:"state",players:[...players.values()].map(p=>({
  id:p.id,name:p.name,team:p.team,x:p.x,z:p.z,yaw:p.yaw,hp:p.hp,stamina:p.stamina,
  alive:p.alive,weapon:p.weapon,blocking:p.blocking,blockDir:p.blockDir,kills:p.kills,deaths:p.deaths,
  attack:p.attack,attackAt:p.attackAt
 }))};
}
function broadcast(){const s=JSON.stringify(publicState());for(const ws of sockets.keys())if(ws.readyState===WebSocket.OPEN)ws.send(s);}
function teamCount(team){return [...players.values()].filter(p=>p.team===team).length;}
function spawn(team){
 return {x:team==="Athens"?-27+Math.random()*8:27-Math.random()*8,z:-22+Math.random()*44};
}
wss.on("connection",ws=>{
 const id=String(nextId++);sockets.set(ws,id);send(ws,{type:"welcome",id});
 ws.on("message",raw=>{
  let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==="join"){
   if(players.has(id))return;
   const team=m.team==="Sparta"?"Sparta":"Athens";
   if(teamCount(team)>=MAX_PER_TEAM){send(ws,{type:"error",message:`${team} is full (30/30). Choose the other side.`});return;}
   const pos=spawn(team);
   players.set(id,{id,name:String(m.name||"Hoplite").slice(0,16),team,x:pos.x,z:pos.z,yaw:team==="Athens"?0:Math.PI,
    hp:100,stamina:100,alive:true,weapon:["spear","sword","kopis","bow"].includes(m.weapon)?m.weapon:"spear",
    blocking:false,blockDir:0,kills:0,deaths:0,lastUpdate:Date.now(),lastAttack:0,attack:"",attackAt:0});
   send(ws,{type:"joined",id,team});broadcast();return;
  }
  const p=players.get(id);if(!p)return;
  if(m.type==="move"&&p.alive){
   const now=Date.now(),dt=clamp((now-p.lastUpdate)/1000,0,.12);p.lastUpdate=now;
   const dx=clamp(Number(m.dx)||0,-1,1),dz=clamp(Number(m.dz)||0,-1,1),mag=Math.hypot(dx,dz)||1;
   const sprint=!!m.sprint&&p.stamina>3,speed=sprint?8.1:5.1;
   p.x=clamp(p.x+dx/mag*speed*dt,-WORLD/2+3,WORLD/2-3);
   p.z=clamp(p.z+dz/mag*speed*dt,-WORLD/2+3,WORLD/2-3);
   if(Math.abs(dx)+Math.abs(dz)>.05)p.yaw=Math.atan2(dx,dz);
   p.stamina=clamp(p.stamina+(sprint?-22:9)*dt,0,100);
   if(m.yaw!==undefined && Number.isFinite(+m.yaw))p.yaw=+m.yaw;
  }
  if(m.type==="look"&&p.alive&&Number.isFinite(+m.yaw))p.yaw=+m.yaw;
  if(m.type==="block"&&p.alive){p.blocking=!!m.on;p.blockDir=Number.isFinite(+m.dir)?+m.dir:p.yaw;}
  if(m.type==="weapon"&&["spear","sword","kopis","bow"].includes(m.weapon))p.weapon=m.weapon;
  if(m.type==="attack"&&p.alive){
   const now=Date.now();if(now-p.lastAttack<650||p.stamina<10)return;
   p.lastAttack=now;p.stamina-=10;p.attack=m.kind||"thrust";p.attackAt=now;
   const range=p.weapon==="spear"?4.1:p.weapon==="bow"?13:2.8;
   const arc=p.weapon==="spear"?.62:p.weapon==="bow"?.20:.95;
   let target=null,best=range;
   for(const q of players.values()){
    if(q.team===p.team||!q.alive)continue;
    const vx=q.x-p.x,vz=q.z-p.z,d=Math.hypot(vx,vz);
    const a=Math.atan2(vx,vz),diff=Math.atan2(Math.sin(a-p.yaw),Math.cos(a-p.yaw));
    if(d<best&&Math.abs(diff)<arc){best=d;target=q;}
   }
   if(target){
    const base=p.weapon==="spear"?36:p.weapon==="bow"?24:p.weapon==="kopis"?39:32;
    const towardAttacker=Math.atan2(p.x-target.x,p.z-target.z);
    const shieldAngle=Math.atan2(Math.sin(towardAttacker-target.blockDir),Math.cos(towardAttacker-target.blockDir));
    const shieldCovers=target.blocking&&Math.abs(shieldAngle)<1.05;
    const damage=shieldCovers?base*.22:base;
    target.hp=Math.max(0,target.hp-damage);
    if(target.hp<=0){
     target.alive=false;p.kills++;target.deaths++;
     setTimeout(()=>{if(players.has(target.id)){const sp=spawn(target.team);target.x=sp.x;target.z=sp.z;target.hp=100;target.stamina=100;target.alive=true;target.blocking=false;broadcast();}},6500);
    }
   }
  }
 });
 ws.on("close",()=>{sockets.delete(ws);players.delete(id);broadcast();});
});
setInterval(()=>{
 for(const p of players.values()){if(p.alive)p.stamina=clamp(p.stamina+(p.blocking?1.5:4)*.25,0,100);}
 broadcast();
},100);
server.listen(PORT,()=>console.log("Peloponnesian Front 3D listening on "+PORT));
